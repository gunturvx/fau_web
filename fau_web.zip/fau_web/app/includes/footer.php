

    <!-- Footer -->
    <footer class="footer footer-widgets">
            <div class="container">
                <div class="row"> 
                    <div class="col-lg-3">  
                        <div class="widget widget_text widget_info">
                            <h5 class="widget-title">Tentang Kami</h5>
                            <div class="textwidget">                                
                                <p>Cari Resep Makanan Terlengkap disini Temukan bahan-bahan, alat-alat dan cara pembuatan berbagai jenis roti hanya dengan sekali klik</p>                      
                            </div><!-- /.textwidget -->
                        </div><!-- /.widget -->      
                    </div><!-- /.col-lg-3 --> 

                    <div class="col-lg-3">  
                        <div id="nav_menu-2" class="widget widget_nav_menu">
                            <h5 class="widget-title">Menu</h5>
                            <div class="wrap-menufooter clearfix">
                                <ul class="menu one-half">
                                    <li class="menu-item"><a href="index.php">Home</a></li>
                                    <li class="menu-item"><a href="resep_lengkap.php">Resep Lengkap</a></li>
                                    <li class="menu-item"><a href="favorite.php">Favorite</a></li>
                                     <li class="menu-item"><a href="resep_with_api.php">Resep Terupdate</a></li>
                                    <li class="menu-item"><a href="about.php">About Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- /.col-lg-3 -->

                
                </div><!-- /.row -->    
            </div><!-- /.container -->
            <div class="container">
                <div class="bottom">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="copyright"> 
                                <p>Copyright © 2022. Designer by <a href="#">Fau Web</a>. All Rights Reserved.
                                </p>
                            </div>                   
                        </div><!-- /.col-md-12 -->
                        <div class="col-md-6 col-sm-6">
                            <div class="social-links float-right">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>                  
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
    </footer>
