<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/admin/posts/index.php'; ?>">Manage Rekomendasi</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/users/index.php'; ?>">Manage Users</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/topics/index.php'; ?>">Manage Topik Rekomendasi</a></li>
    </ul>
</div>